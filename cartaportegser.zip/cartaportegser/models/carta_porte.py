from odoo import fields, models


class carta_porte (models.Model):
    _inherit = "account.move"